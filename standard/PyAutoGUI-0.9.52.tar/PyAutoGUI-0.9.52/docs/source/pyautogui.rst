pyautogui package
=================

Submodules
----------

pyautogui.keynames module
-------------------------

.. automodule:: pyautogui.keynames
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: pyautogui
   :members:
   :undoc-members:
   :show-inheritance:
